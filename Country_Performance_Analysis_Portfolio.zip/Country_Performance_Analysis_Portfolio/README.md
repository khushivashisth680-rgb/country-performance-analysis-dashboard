# Country Performance Analysis Dashboard

## Project Overview
An Excel-based country performance analysis project designed to analyze and compare countries across multiple indicators and present the results through a consolidated dashboard.

## Workbook Structure
The workbook contains the following analysis areas:
- Dashboard
- Raw Data
- Total Score
- C Analysis
- E Analysis
- P Analysis
- S Analysis
- X1 Analysis & Final Analysis

## Analysis Performed
- Organized and analyzed raw country-level indicator data.
- Calculated indicator-level summary statistics using Excel formulas.
- Compared country performance across C, E, P, S and X indicators.
- Developed a Total Score and Top 10 country analysis.
- Consolidated the indicator analysis into a final analysis.
- Created charts and a dashboard for clear data visualization.

## Excel Techniques Used
- AVERAGE
- COUNTIF
- MAX
- MIN
- Data organization and analysis
- Ranking / Top 10 analysis
- Chart-based data visualization
- Dashboard creation

## Key Deliverable
The main deliverable is the `Country_Performance_Analysis_Dashboard.xlsx` workbook, containing the complete analysis and dashboard.

## Portfolio Note
This project demonstrates practical skills in Microsoft Excel, data analysis, data interpretation and data visualization.
